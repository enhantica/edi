# %% [markdown]
# # LaB6 — powder neutron CW — FCJ asymmetry
#
# Verifies the LaB6 baseline with only the **Finger-Cox-Jephcoat axial-divergence
# asymmetry** enabled (`cwl-thompson-cox-hastings`, `S_L` = `D_L` = 0.08 — the FullProf
# reference's own values, fixed, as nothing fits them).
#
# **The kernel follows FullProf's own library.** The TCH pseudo-Voigt core is convolved with
# the FCJ aberration by Gauss-Legendre quadrature exactly as crysfml's `Prof_Val` does it,
# including its node count on the signed integration span (6 nodes above 90°) — measured
# closer to FullProf than a finer integral (upstream design). Upstream's page records a known
# discrepancy instead: cryspy has no FCJ term.
#
# **Scattering table.** FullProf's own neutron lengths, as on the basic page.
#
# **The bounds are labelled regression pins** — this page's own measured closeness with
# stated headroom (measured at development hub : profile difference 0.43 %, max deviation 0.37 %,
# area ratio 0.99960, correlation 0.9999903).

# %%
from edi import ExperimentFactory
from edi import Project
from edi import StructureFactory
from edi import verification as verify

# %% [markdown]
# ## Load the FullProf reference

# %%
FULLPROF_PROJECT_DIR = 'pd-neut-cwl_lab6-echidna_fcj-asymmetry'
FULLPROF_PRF_FILE = 'ECH0030684_LaB6_1p622A_fcj.prf'
FULLPROF_SUM_FILE = 'ECH0030684_LaB6_1p622A_fcj.sum'
FULLPROF_BAC_FILE = 'ECH0030684_LaB6_1p622A_fcj.bac'
FULLPROF_LABEL = verify.fullprof_label(FULLPROF_PROJECT_DIR, FULLPROF_SUM_FILE)

# Structure
FULLPROF_SPACE_GROUP = 'P m -3 m'  # FullProf Space group symbol
FULLPROF_CELL_LENGTH_A = 4.156885  # FullProf a
FULLPROF_ATOM_SITES = [
    # FullProf Atom, Typ, Wyckoff, (X, Y, Z), Occ (chemical), Biso
    ('La', 'La', 'a', (0.0, 0.0, 0.0), 1.0, 0.25812),
    ('B', 'B', 'f', (0.19972, 0.5, 0.5), 1.0, 0.11925),
]
# FullProf's own neutron scattering lengths (fm)
FULLPROF_SCATTERING_LENGTHS_FM = {'La': 8.240, 'B': 5.300}

# Experiment
FULLPROF_ZERO = -0.45778  # FullProf Zero
FULLPROF_SCALE = 42.98374  # FullProf Scale
FULLPROF_WAVELENGTH = 1.623899  # FullProf Lambda
FULLPROF_U = 0.143431  # FullProf U
FULLPROF_V = -0.523140  # FullProf V
FULLPROF_W = 0.590412  # FullProf W
FULLPROF_X = 0.0  # FullProf X
FULLPROF_Y = 0.054515  # FullProf Y
FULLPROF_WDT = 12.0  # FullProf Wdt
FULLPROF_S_L = 0.08  # FullProf S_L
FULLPROF_D_L = 0.08  # FullProf D_L
FULLPROF_EXCLUDED_REGIONS = [(0.0, 10.0), (164.0, 180.0)]  # FullProf Excluded regions

x, calc_fullprof = verify.load_fullprof_calc_profile(
    FULLPROF_PROJECT_DIR,
    FULLPROF_PRF_FILE,
    FULLPROF_BAC_FILE,
    FULLPROF_ZERO,
)

# %% [markdown]
# ## Define the structure

# %%
structure = StructureFactory.from_dict({
    'name': 'lab6',
    'space_group': {'name_h_m': FULLPROF_SPACE_GROUP},
    'cell': {'length_a': FULLPROF_CELL_LENGTH_A},
    'atom_sites': [
        {
            'id': site_id,
            'type_symbol': type_symbol,
            'wyckoff_letter': wyckoff,
            'fract': fract,
            'occupancy': occupancy,
            'adp_iso': adp_iso,
        }
        for site_id, type_symbol, wyckoff, fract, occupancy, adp_iso in FULLPROF_ATOM_SITES
    ],
    'scattering_lengths_fm': FULLPROF_SCATTERING_LENGTHS_FM,
})

# %% [markdown]
# ## Define the experiment

# %%
experiment = ExperimentFactory.from_dict({
    'name': 'lab6',
    'experiment_type': {'beam_mode': 'constant wavelength'},
    'peak': {
        'type': 'cwl-thompson-cox-hastings',
        'cutoff_fwhm': FULLPROF_WDT,
        'broad_gauss_u': FULLPROF_U,
        'broad_gauss_v': FULLPROF_V,
        'broad_gauss_w': FULLPROF_W,
        'broad_lorentz_x': FULLPROF_X,
        'broad_lorentz_y': FULLPROF_Y,
        'asym_fcj_1': FULLPROF_S_L,
        'asym_fcj_2': FULLPROF_D_L,
    },
    'instrument': {
        'setup_wavelength': FULLPROF_WAVELENGTH,
        'calib_twotheta_offset': FULLPROF_ZERO,
    },
    'linked_structure': {'scale': FULLPROF_SCALE},
    'excluded_regions': FULLPROF_EXCLUDED_REGIONS,
})

# %% [markdown]
# ## Build the project

# %%
project = Project()
project.structure = structure
project.experiment = experiment
verify.set_reference_as_measured(project.experiment, x, calc_fullprof)

# %% [markdown]
# ## Calculate the pattern

# %%
project.analysis.calculate()

# %% [markdown]
# ## edi-crysta VS FullProf

# %%
calc_ed_crysta = verify.restrict_to_included(
    project.experiment,
    project.experiment.data.intensity_calc,
)
LABEL_ED_CRYSTA = verify.engine_label('crysta')

verify.plot_pattern_comparison(
    project.experiment,
    reference=calc_fullprof,
    candidate=calc_ed_crysta,
    reference_label=FULLPROF_LABEL,
    candidate_label=LABEL_ED_CRYSTA,
)

# %%
verify.assert_patterns_agree(
    [
        (
            f'{LABEL_ED_CRYSTA} vs {FULLPROF_LABEL}',
            verify.restrict_to_included(project.experiment, calc_fullprof),
            calc_ed_crysta,
        ),
    ],
    tolerances=verify.AgreementTolerances(
        max_profile_difference_percent=0.50,
        max_deviation_percent=0.45,
        min_intensity_ratio=0.9993,
        max_intensity_ratio=1.0007,
        min_correlation=0.99998,
    ),
)
